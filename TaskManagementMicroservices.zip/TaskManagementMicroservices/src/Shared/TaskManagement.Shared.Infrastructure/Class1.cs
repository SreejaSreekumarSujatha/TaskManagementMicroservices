﻿namespace TaskManagement.Shared.Infrastructure;

public class Class1
{

}
