﻿namespace TaskManagement.Shared.Events;

public class Class1
{

}
