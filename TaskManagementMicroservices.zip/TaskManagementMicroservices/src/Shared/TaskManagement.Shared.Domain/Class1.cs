﻿namespace TaskManagement.Shared.Domain;

public class Class1
{

}
