﻿namespace TaskManagement.User.Infrastructure;

public class Class1
{

}
