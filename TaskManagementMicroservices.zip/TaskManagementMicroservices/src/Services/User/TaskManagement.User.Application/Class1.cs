﻿namespace TaskManagement.User.Application;

public class Class1
{

}
