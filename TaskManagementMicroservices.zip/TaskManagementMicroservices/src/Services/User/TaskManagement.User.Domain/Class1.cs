﻿namespace TaskManagement.User.Domain;

public class Class1
{

}
